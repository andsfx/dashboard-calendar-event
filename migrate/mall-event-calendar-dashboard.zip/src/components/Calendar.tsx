import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { MallEvent } from '../data/events';

interface CalendarProps {
  currentDate: Date;
  onPrevMonth: () => void;
  onNextMonth: () => void;
  events: MallEvent[];
  onDateClick: (date: Date) => void;
  selectedDate: Date | null;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
];

function getDaysInMonth(y: number, m: number) {
  return new Date(y, m + 1, 0).getDate();
}
function getFirstDayOfMonth(y: number, m: number) {
  return new Date(y, m, 1).getDay();
}
function fmtKey(y: number, m: number, d: number) {
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

export default function Calendar({
  currentDate,
  onPrevMonth,
  onNextMonth,
  events,
  onDateClick,
  selectedDate,
}: CalendarProps) {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  const now = new Date();

  const isToday = (day: number) =>
    now.getFullYear() === year && now.getMonth() === month && now.getDate() === day;
  const isSelected = (day: number) =>
    selectedDate &&
    selectedDate.getFullYear() === year &&
    selectedDate.getMonth() === month &&
    selectedDate.getDate() === day;

  const eventMap: Record<string, MallEvent[]> = {};
  events.forEach((ev) => {
    if (!eventMap[ev.date]) eventMap[ev.date] = [];
    eventMap[ev.date].push(ev);
  });

  const prevMonthDays = getDaysInMonth(year, month - 1);
  const trailing: number[] = [];
  for (let i = firstDay - 1; i >= 0; i--) trailing.push(prevMonthDays - i);

  const totalCells = trailing.length + daysInMonth;
  const leading = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);

  const navBtnStyle: React.CSSProperties = {
    width: 36,
    height: 36,
    borderRadius: 10,
    border: '1.5px solid #e8ecf1',
    background: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    color: '#64748b',
  };

  return (
    <div className="card animate-fade-in-up" style={{ padding: 24, animationDelay: '150ms' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ fontSize: 20, fontWeight: 800, color: '#1e293b' }}>
            {MONTHS[month]} {year}
          </h2>
          <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 2, fontWeight: 500 }}>
            Event Calendar
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <button
            onClick={onPrevMonth}
            style={navBtnStyle}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#0bb5ae';
              e.currentTarget.style.background = 'rgba(11,181,174,0.05)';
              e.currentTarget.style.color = '#0bb5ae';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#e8ecf1';
              e.currentTarget.style.background = '#fff';
              e.currentTarget.style.color = '#64748b';
            }}
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={() => onDateClick(new Date())}
            style={{
              padding: '8px 16px',
              borderRadius: 10,
              border: '1.5px solid #e8ecf1',
              background: '#fff',
              fontSize: 12,
              fontWeight: 700,
              color: '#64748b',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#0bb5ae';
              e.currentTarget.style.background = 'rgba(11,181,174,0.05)';
              e.currentTarget.style.color = '#0bb5ae';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#e8ecf1';
              e.currentTarget.style.background = '#fff';
              e.currentTarget.style.color = '#64748b';
            }}
          >
            Today
          </button>
          <button
            onClick={onNextMonth}
            style={navBtnStyle}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#0bb5ae';
              e.currentTarget.style.background = 'rgba(11,181,174,0.05)';
              e.currentTarget.style.color = '#0bb5ae';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#e8ecf1';
              e.currentTarget.style.background = '#fff';
              e.currentTarget.style.color = '#64748b';
            }}
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Day Headers */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, marginBottom: 4 }}>
        {DAYS.map((day) => (
          <div
            key={day}
            style={{
              padding: '10px 0',
              textAlign: 'center',
              fontSize: 11,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.08em',
              color: '#94a3b8',
            }}
          >
            {day}
          </div>
        ))}
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
        {/* Trailing */}
        {trailing.map((day) => (
          <div
            key={`p-${day}`}
            style={{
              minHeight: 88,
              padding: 6,
              borderRadius: 12,
              color: '#cbd5e1',
            }}
          >
            <span style={{ fontSize: 12, fontWeight: 600 }}>{day}</span>
          </div>
        ))}

        {/* Days */}
        {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
          const key = fmtKey(year, month, day);
          const dayEvents = eventMap[key] || [];
          const td = isToday(day);
          const sel = isSelected(day);

          return (
            <button
              key={day}
              onClick={() => onDateClick(new Date(year, month, day))}
              style={{
                minHeight: 88,
                padding: 6,
                borderRadius: 12,
                textAlign: 'left',
                display: 'flex',
                flexDirection: 'column',
                border: sel ? '2px solid #0bb5ae' : '2px solid transparent',
                background: sel
                  ? 'rgba(11, 181, 174, 0.04)'
                  : td
                  ? 'rgba(11, 181, 174, 0.03)'
                  : 'transparent',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                if (!sel) {
                  e.currentTarget.style.background = 'rgba(11, 181, 174, 0.04)';
                  e.currentTarget.style.borderColor = 'rgba(11, 181, 174, 0.2)';
                }
              }}
              onMouseLeave={(e) => {
                if (!sel) {
                  e.currentTarget.style.background = td ? 'rgba(11, 181, 174, 0.03)' : 'transparent';
                  e.currentTarget.style.borderColor = 'transparent';
                }
              }}
            >
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: 28,
                  height: 28,
                  borderRadius: 8,
                  fontSize: 12,
                  fontWeight: td ? 800 : sel ? 700 : 600,
                  color: td ? '#fff' : sel ? '#067370' : '#475569',
                  background: td
                    ? 'linear-gradient(135deg, #0bb5ae 0%, #089490 100%)'
                    : 'transparent',
                  boxShadow: td ? '0 2px 8px rgba(11, 181, 174, 0.35)' : 'none',
                }}
              >
                {day}
              </span>
              <div style={{ marginTop: 4, display: 'flex', flexDirection: 'column', gap: 2, overflow: 'hidden' }}>
                {dayEvents.slice(0, 2).map((ev) => (
                  <div
                    key={ev.id}
                    style={{
                      padding: '2px 6px',
                      borderRadius: 5,
                      fontSize: 9,
                      fontWeight: 700,
                      lineHeight: 1.5,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      background: ev.isVip
                        ? 'rgba(236, 72, 153, 0.12)'
                        : 'rgba(11, 181, 174, 0.1)',
                      color: ev.isVip ? '#be185d' : '#067370',
                    }}
                  >
                    {ev.title}
                  </div>
                ))}
                {dayEvents.length > 2 && (
                  <span style={{ fontSize: 9, fontWeight: 600, color: '#94a3b8', paddingLeft: 4 }}>
                    +{dayEvents.length - 2} more
                  </span>
                )}
              </div>
            </button>
          );
        })}

        {/* Leading */}
        {Array.from({ length: leading }, (_, i) => i + 1).map((day) => (
          <div
            key={`n-${day}`}
            style={{
              minHeight: 88,
              padding: 6,
              borderRadius: 12,
              color: '#cbd5e1',
            }}
          >
            <span style={{ fontSize: 12, fontWeight: 600 }}>{day}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
