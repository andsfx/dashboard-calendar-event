import {
  LayoutDashboard,
  CalendarDays,
  Clock,
  Music,
  Baby,
  Tags,
  Settings,
  ChevronLeft,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface SidebarProps {
  activeNav: string;
  onNavChange: (nav: string) => void;
  collapsed: boolean;
  onToggle: () => void;
}

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'calendar', label: 'Full Calendar', icon: CalendarDays },
  { id: 'upcoming', label: 'Upcoming Events', icon: Clock },
];

const CATEGORY_ITEMS = [
  { id: 'cat-music', label: 'Music', icon: Music, dot: '#0891b2' },
  { id: 'cat-kids', label: 'Kids', icon: Baby, dot: '#f59e0b' },
  { id: 'cat-sale', label: 'Sale', icon: Tags, dot: '#10b981' },
];

export default function Sidebar({ activeNav, onNavChange, collapsed, onToggle }: SidebarProps) {
  return (
    <aside
      style={{
        width: collapsed ? 76 : 264,
        background: 'linear-gradient(180deg, #ffffff 0%, #f8fffe 100%)',
        borderRight: '1px solid #e8ecf1',
        transition: 'width 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
      }}
      className="fixed left-0 top-0 z-40 flex h-screen flex-col"
    >
      {/* Logo */}
      <div
        className="flex items-center gap-3 px-5"
        style={{ height: 72, borderBottom: '1px solid #e8ecf1' }}
      >
        <div
          className="flex flex-shrink-0 items-center justify-center"
          style={{
            width: 40,
            height: 40,
            borderRadius: 12,
            background: 'linear-gradient(135deg, #0bb5ae 0%, #067370 100%)',
            boxShadow: '0 4px 12px rgba(11, 181, 174, 0.3)',
          }}
        >
          <Sparkles size={20} color="#fff" />
        </div>
        {!collapsed && (
          <div className="animate-fade-in overflow-hidden">
            <h1 style={{ fontSize: 14, fontWeight: 800, color: '#1e293b', lineHeight: 1.2 }}>
              Metropolitan
            </h1>
            <p style={{ fontSize: 11, fontWeight: 600, color: '#0bb5ae', lineHeight: 1.3 }}>
              Mall Bekasi
            </p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-5">
        {/* Menu Section */}
        {!collapsed && (
          <p
            className="px-3 mb-2"
            style={{
              fontSize: 10,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              color: '#94a3b8',
            }}
          >
            Menu
          </p>
        )}
        <ul className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.id;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onNavChange(item.id)}
                  title={collapsed ? item.label : undefined}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    width: '100%',
                    padding: collapsed ? '10px 14px' : '10px 14px',
                    borderRadius: 12,
                    fontSize: 13,
                    fontWeight: isActive ? 700 : 500,
                    color: isActive ? '#067370' : '#64748b',
                    background: isActive ? 'rgba(11, 181, 174, 0.08)' : 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    position: 'relative',
                  }}
                  onMouseEnter={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.background = 'rgba(11, 181, 174, 0.05)';
                      e.currentTarget.style.color = '#067370';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.color = '#64748b';
                    }
                  }}
                >
                  <Icon
                    size={18}
                    style={{ flexShrink: 0, color: isActive ? '#0bb5ae' : '#94a3b8' }}
                  />
                  {!collapsed && <span>{item.label}</span>}
                  {isActive && (
                    <div
                      style={{
                        position: 'absolute',
                        right: collapsed ? 8 : 12,
                        top: '50%',
                        transform: 'translateY(-50%)',
                        width: 6,
                        height: 6,
                        borderRadius: '50%',
                        background: '#0bb5ae',
                      }}
                    />
                  )}
                </button>
              </li>
            );
          })}
        </ul>

        {/* Categories Section */}
        <div className="mt-6">
          {!collapsed && (
            <p
              className="px-3 mb-2"
              style={{
                fontSize: 10,
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                color: '#94a3b8',
              }}
            >
              Categories
            </p>
          )}
          <ul className="space-y-1">
            {CATEGORY_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onNavChange(item.id)}
                    title={collapsed ? item.label : undefined}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 12,
                      width: '100%',
                      padding: '10px 14px',
                      borderRadius: 12,
                      fontSize: 13,
                      fontWeight: isActive ? 700 : 500,
                      color: isActive ? '#067370' : '#64748b',
                      background: isActive ? 'rgba(11, 181, 174, 0.08)' : 'transparent',
                      border: 'none',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      if (!isActive) {
                        e.currentTarget.style.background = 'rgba(11, 181, 174, 0.05)';
                        e.currentTarget.style.color = '#067370';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!isActive) {
                        e.currentTarget.style.background = 'transparent';
                        e.currentTarget.style.color = '#64748b';
                      }
                    }}
                  >
                    <div
                      style={{
                        width: 18,
                        height: 18,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0,
                        position: 'relative',
                      }}
                    >
                      <Icon size={18} style={{ color: isActive ? item.dot : '#94a3b8' }} />
                    </div>
                    {!collapsed && <span>{item.label}</span>}
                    {!collapsed && (
                      <div
                        style={{
                          marginLeft: 'auto',
                          width: 8,
                          height: 8,
                          borderRadius: '50%',
                          background: item.dot,
                          opacity: 0.6,
                        }}
                      />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* Bottom */}
      <div style={{ borderTop: '1px solid #e8ecf1', padding: '12px' }}>
        <button
          onClick={() => onNavChange('settings')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            width: '100%',
            padding: '10px 14px',
            borderRadius: 12,
            fontSize: 13,
            fontWeight: activeNav === 'settings' ? 700 : 500,
            color: activeNav === 'settings' ? '#067370' : '#64748b',
            background: activeNav === 'settings' ? 'rgba(11, 181, 174, 0.08)' : 'transparent',
            border: 'none',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onMouseEnter={(e) => {
            if (activeNav !== 'settings') {
              e.currentTarget.style.background = 'rgba(11, 181, 174, 0.05)';
              e.currentTarget.style.color = '#067370';
            }
          }}
          onMouseLeave={(e) => {
            if (activeNav !== 'settings') {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = '#64748b';
            }
          }}
        >
          <Settings size={18} style={{ flexShrink: 0, color: '#94a3b8' }} />
          {!collapsed && <span>Settings</span>}
        </button>

        <button
          onClick={onToggle}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            width: '100%',
            padding: '10px 14px',
            borderRadius: 12,
            fontSize: 13,
            fontWeight: 500,
            color: '#94a3b8',
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#f1f5f9';
            e.currentTarget.style.color = '#64748b';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#94a3b8';
          }}
        >
          {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  );
}
