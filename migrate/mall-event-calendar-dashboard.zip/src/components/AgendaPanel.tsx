import { MapPin, Clock, Star, CalendarX } from 'lucide-react';
import type { MallEvent } from '../data/events';
import { CATEGORY_CONFIG } from '../data/events';

interface AgendaPanelProps {
  events: MallEvent[];
  selectedDate: Date | null;
}

function formatDisplayDate(date: Date): string {
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

function isToday(date: Date): boolean {
  const today = new Date();
  return (
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate()
  );
}

export default function AgendaPanel({ events, selectedDate }: AgendaPanelProps) {
  const displayDate = selectedDate || new Date();
  const dateKey = `${displayDate.getFullYear()}-${String(displayDate.getMonth() + 1).padStart(2, '0')}-${String(displayDate.getDate()).padStart(2, '0')}`;
  const dayEvents = events
    .filter((e) => e.date === dateKey)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const todayFlag = isToday(displayDate);

  return (
    <div className="card animate-slide-in" style={{ padding: 24, animationDelay: '250ms' }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <h3 style={{ fontSize: 17, fontWeight: 800, color: '#1e293b' }}>
            {todayFlag ? "Today's Agenda" : 'Schedule'}
          </h3>
          {todayFlag && (
            <span
              style={{
                padding: '3px 10px',
                borderRadius: 20,
                background: 'rgba(11, 181, 174, 0.1)',
                color: '#067370',
                fontSize: 10,
                fontWeight: 700,
              }}
            >
              ● Live
            </span>
          )}
        </div>
        <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 4, fontWeight: 500 }}>
          {formatDisplayDate(displayDate)}
        </p>
      </div>

      {/* Events */}
      {dayEvents.length === 0 ? (
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '48px 20px',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              width: 60,
              height: 60,
              borderRadius: 16,
              background: '#f1f5f9',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 14,
            }}
          >
            <CalendarX size={26} color="#cbd5e1" />
          </div>
          <p style={{ fontSize: 14, fontWeight: 700, color: '#94a3b8' }}>No events scheduled</p>
          <p style={{ fontSize: 12, color: '#cbd5e1', marginTop: 4, fontWeight: 500 }}>
            Select another date or add a new event
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {dayEvents.map((event, index) => {
            const cat = CATEGORY_CONFIG[event.category];
            return (
              <div
                key={event.id}
                className="animate-fade-in-up"
                style={{
                  position: 'relative',
                  padding: 16,
                  borderRadius: 14,
                  border: event.isVip ? '1.5px solid rgba(236, 72, 153, 0.2)' : '1.5px solid #e8ecf1',
                  background: event.isVip ? 'rgba(253, 242, 248, 0.5)' : '#fff',
                  transition: 'all 0.2s ease',
                  animationDelay: `${300 + index * 80}ms`,
                  cursor: 'default',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = event.isVip ? 'rgba(236, 72, 153, 0.4)' : '#0bb5ae';
                  e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.05)';
                  e.currentTarget.style.transform = 'translateY(-1px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = event.isVip ? 'rgba(236, 72, 153, 0.2)' : '#e8ecf1';
                  e.currentTarget.style.boxShadow = 'none';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                {/* VIP Badge */}
                {event.isVip && (
                  <div
                    style={{
                      position: 'absolute',
                      top: -6,
                      right: -6,
                      width: 22,
                      height: 22,
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #ec4899, #db2777)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: '0 2px 6px rgba(236, 72, 153, 0.35)',
                      border: '2px solid #fff',
                    }}
                  >
                    <Star size={10} color="#fff" fill="#fff" />
                  </div>
                )}

                {/* Time */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                  <Clock size={12} color={event.isVip ? '#ec4899' : '#0bb5ae'} />
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#64748b' }}>
                    {event.startTime} — {event.endTime}
                  </span>
                </div>

                {/* Title */}
                <h4 style={{ fontSize: 14, fontWeight: 800, color: '#1e293b', marginBottom: 8 }}>
                  {event.title}
                </h4>

                {/* Location + Category */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#94a3b8' }}>
                    <MapPin size={12} />
                    <span style={{ fontSize: 11, fontWeight: 500 }}>{event.location}</span>
                  </div>
                  <span
                    style={{
                      padding: '2px 8px',
                      borderRadius: 6,
                      fontSize: 10,
                      fontWeight: 700,
                      background: cat.bgColor,
                      color: cat.color,
                    }}
                  >
                    {cat.icon} {cat.label}
                  </span>
                </div>

                {/* Guests */}
                {event.guests && event.guests.length > 0 && (
                  <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ display: 'flex' }}>
                      {event.guests.slice(0, 4).map((guest, gi) => (
                        <div
                          key={gi}
                          title={guest.name}
                          style={{
                            width: 26,
                            height: 26,
                            borderRadius: '50%',
                            border: '2px solid #fff',
                            marginLeft: gi > 0 ? -8 : 0,
                            overflow: 'hidden',
                            background: 'linear-gradient(135deg, #0bb5ae, #067370)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: 9,
                            fontWeight: 800,
                            boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                          }}
                        >
                          {guest.name.charAt(0)}
                        </div>
                      ))}
                      {event.guests.length > 4 && (
                        <div
                          style={{
                            width: 26,
                            height: 26,
                            borderRadius: '50%',
                            border: '2px solid #fff',
                            marginLeft: -8,
                            background: '#f1f5f9',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: 9,
                            fontWeight: 800,
                            color: '#64748b',
                          }}
                        >
                          +{event.guests.length - 4}
                        </div>
                      )}
                    </div>
                    <span style={{ fontSize: 10, color: '#94a3b8', fontWeight: 500 }}>
                      {event.guests.map((g) => g.name).join(', ')}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Quick Stats */}
      <div
        style={{
          marginTop: 20,
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: 1,
          background: '#e8ecf1',
          borderRadius: 14,
          overflow: 'hidden',
        }}
      >
        {[
          { label: 'Events', value: dayEvents.length, color: '#0bb5ae' },
          { label: 'VIP', value: dayEvents.filter((e) => e.isVip).length, color: '#ec4899' },
          { label: 'Guests', value: dayEvents.reduce((a, e) => a + (e.guests?.length || 0), 0), color: '#64748b' },
        ].map((stat) => (
          <div
            key={stat.label}
            style={{
              background: '#f8fafc',
              padding: '14px 12px',
              textAlign: 'center',
            }}
          >
            <p style={{ fontSize: 20, fontWeight: 800, color: stat.color }}>{stat.value}</p>
            <p style={{ fontSize: 10, fontWeight: 600, color: '#94a3b8', marginTop: 2 }}>{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
