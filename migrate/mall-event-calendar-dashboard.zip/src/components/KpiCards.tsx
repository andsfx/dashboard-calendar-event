import { CalendarDays, Clock, Megaphone, TrendingUp } from 'lucide-react';

interface KpiCardData {
  title: string;
  value: number;
  subtitle: string;
  icon: React.ReactNode;
  iconBg: string;
  trend: string;
  trendUp: boolean;
  delay: number;
}

function KpiCard({ title, value, subtitle, icon, iconBg, trend, trendUp, delay }: KpiCardData) {
  return (
    <div
      className="card animate-fade-in-up"
      style={{
        padding: 24,
        animationDelay: `${delay}ms`,
        cursor: 'default',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-2px)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)';
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <p style={{ fontSize: 11, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            {title}
          </p>
          <p style={{ fontSize: 32, fontWeight: 800, color: '#1e293b', marginTop: 8, lineHeight: 1 }}>
            {value}
          </p>
          <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 4, fontWeight: 500 }}>{subtitle}</p>
        </div>
        <div
          style={{
            width: 48,
            height: 48,
            borderRadius: 14,
            background: iconBg,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'transform 0.3s ease',
          }}
        >
          {icon}
        </div>
      </div>

      <div style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            padding: '3px 8px',
            borderRadius: 8,
            background: trendUp ? '#ecfdf5' : '#fef2f2',
          }}
        >
          <TrendingUp
            size={12}
            style={{
              color: trendUp ? '#10b981' : '#ef4444',
              transform: trendUp ? 'none' : 'scaleY(-1)',
            }}
          />
          <span style={{ fontSize: 11, fontWeight: 700, color: trendUp ? '#10b981' : '#ef4444' }}>
            {trend}
          </span>
        </div>
        <span style={{ fontSize: 11, color: '#94a3b8', fontWeight: 500 }}>vs last month</span>
      </div>
    </div>
  );
}

interface KpiCardsProps {
  totalEvents: number;
  upcomingThisWeek: number;
  activePromos: number;
}

export default function KpiCards({ totalEvents, upcomingThisWeek, activePromos }: KpiCardsProps) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
      <KpiCard
        title="Total Events This Month"
        value={totalEvents}
        subtitle="Across all categories"
        icon={<CalendarDays size={22} color="#0bb5ae" />}
        iconBg="rgba(11, 181, 174, 0.1)"
        trend="+12%"
        trendUp={true}
        delay={0}
      />
      <KpiCard
        title="Upcoming This Week"
        value={upcomingThisWeek}
        subtitle="Next 7 days schedule"
        icon={<Clock size={22} color="#f59e0b" />}
        iconBg="rgba(245, 158, 11, 0.1)"
        trend="+5%"
        trendUp={true}
        delay={100}
      />
      <KpiCard
        title="Active Promos"
        value={activePromos}
        subtitle="Running promotions"
        icon={<Megaphone size={22} color="#ec4899" />}
        iconBg="rgba(236, 72, 153, 0.1)"
        trend="+8%"
        trendUp={true}
        delay={200}
      />
    </div>
  );
}
