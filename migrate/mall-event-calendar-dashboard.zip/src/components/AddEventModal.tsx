import { useState } from 'react';
import { X, CalendarDays, Clock, MapPin, Type, Sparkles } from 'lucide-react';
import type { MallEvent, EventCategory } from '../data/events';

interface AddEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (event: MallEvent) => void;
}

export default function AddEventModal({ isOpen, onClose, onAdd }: AddEventModalProps) {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState<EventCategory>('music');
  const [isVip, setIsVip] = useState(false);
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !date || !startTime || !endTime || !location) return;
    const newEvent: MallEvent = {
      id: `evt-${Date.now()}`,
      title,
      date,
      startTime,
      endTime,
      location,
      category,
      isVip,
      description,
    };
    onAdd(newEvent);
    setTitle('');
    setDate('');
    setStartTime('');
    setEndTime('');
    setLocation('');
    setCategory('music');
    setIsVip(false);
    setDescription('');
  };

  const labelStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    fontSize: 12,
    fontWeight: 700,
    color: '#475569',
    marginBottom: 6,
  };

  const inputStyle: React.CSSProperties = {
    height: 42,
    width: '100%',
    borderRadius: 12,
    border: '1.5px solid #e8ecf1',
    background: '#fff',
    padding: '0 14px',
    fontSize: 13,
    color: '#334155',
    transition: 'all 0.2s ease',
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 50,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20,
      }}
    >
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="animate-fade-in"
        style={{
          position: 'absolute',
          inset: 0,
          background: 'rgba(15, 23, 42, 0.4)',
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)',
        }}
      />

      {/* Modal */}
      <div
        className="animate-scale-in"
        style={{
          position: 'relative',
          width: '100%',
          maxWidth: 480,
          background: 'rgba(255, 255, 255, 0.92)',
          backdropFilter: 'blur(24px) saturate(180%)',
          WebkitBackdropFilter: 'blur(24px) saturate(180%)',
          borderRadius: 20,
          border: '1px solid rgba(255, 255, 255, 0.5)',
          padding: 28,
          boxShadow: '0 24px 48px rgba(0, 0, 0, 0.12), 0 8px 16px rgba(0, 0, 0, 0.06)',
          animationDelay: '50ms',
        }}
      >
        {/* Close */}
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            right: 16,
            top: 16,
            width: 32,
            height: 32,
            borderRadius: 10,
            border: 'none',
            background: 'transparent',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#94a3b8',
            transition: 'all 0.2s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#f1f5f9';
            e.currentTarget.style.color = '#475569';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#94a3b8';
          }}
        >
          <X size={16} />
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 10,
              background: 'linear-gradient(135deg, #ec4899, #db2777)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 12px rgba(236, 72, 153, 0.3)',
            }}
          >
            <Sparkles size={18} color="#fff" />
          </div>
          <div>
            <h2 style={{ fontSize: 18, fontWeight: 800, color: '#1e293b' }}>Create New Event</h2>
            <p style={{ fontSize: 12, color: '#94a3b8', fontWeight: 500 }}>
              Fill in the details below
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} style={{ marginTop: 20 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Title */}
            <div>
              <label style={labelStyle}>
                <Type size={14} /> Event Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Jazz Night Live"
                required
                style={inputStyle}
              />
            </div>

            {/* Date */}
            <div>
              <label style={labelStyle}>
                <CalendarDays size={14} /> Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                style={inputStyle}
              />
            </div>

            {/* Times */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div>
                <label style={labelStyle}>
                  <Clock size={14} /> Start
                </label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  required
                  style={inputStyle}
                />
              </div>
              <div>
                <label style={labelStyle}>
                  <Clock size={14} /> End
                </label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  required
                  style={inputStyle}
                />
              </div>
            </div>

            {/* Location */}
            <div>
              <label style={labelStyle}>
                <MapPin size={14} /> Location
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., Main Atrium"
                required
                style={inputStyle}
              />
            </div>

            {/* Category + VIP */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, alignItems: 'end' }}>
              <div>
                <label style={labelStyle}>Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as EventCategory)}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                >
                  <option value="music">🎵 Music</option>
                  <option value="kids">🧸 Kids</option>
                  <option value="sale">🏷️ Sale</option>
                  <option value="food">🍔 Food</option>
                  <option value="fashion">👗 Fashion</option>
                  <option value="vip">⭐ VIP</option>
                </select>
              </div>
              <div
                style={{
                  height: 42,
                  display: 'flex',
                  alignItems: 'center',
                  paddingLeft: 4,
                }}
              >
                <label
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    cursor: 'pointer',
                    userSelect: 'none',
                  }}
                >
                  <div
                    onClick={() => setIsVip(!isVip)}
                    style={{
                      width: 44,
                      height: 24,
                      borderRadius: 12,
                      background: isVip
                        ? 'linear-gradient(135deg, #ec4899, #db2777)'
                        : '#e2e8f0',
                      position: 'relative',
                      cursor: 'pointer',
                      transition: 'background 0.3s ease',
                      boxShadow: isVip ? '0 2px 8px rgba(236, 72, 153, 0.3)' : 'none',
                    }}
                  >
                    <div
                      style={{
                        position: 'absolute',
                        top: 2,
                        left: isVip ? 22 : 2,
                        width: 20,
                        height: 20,
                        borderRadius: '50%',
                        background: '#fff',
                        boxShadow: '0 1px 4px rgba(0,0,0,0.15)',
                        transition: 'left 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
                      }}
                    />
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#475569' }}>VIP Event</span>
                </label>
              </div>
            </div>

            {/* Description */}
            <div>
              <label style={labelStyle}>Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                placeholder="Brief description of the event..."
                style={{
                  ...inputStyle,
                  height: 'auto',
                  padding: '10px 14px',
                  resize: 'none',
                }}
              />
            </div>
          </div>

          {/* Actions */}
          <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
            <button
              type="button"
              onClick={onClose}
              style={{
                flex: 1,
                height: 44,
                borderRadius: 12,
                border: '1.5px solid #e8ecf1',
                background: '#fff',
                fontSize: 13,
                fontWeight: 700,
                color: '#64748b',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#cbd5e1';
                e.currentTarget.style.background = '#f8fafc';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = '#e8ecf1';
                e.currentTarget.style.background = '#fff';
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              style={{
                flex: 1,
                height: 44,
                borderRadius: 12,
                border: 'none',
                background: 'linear-gradient(135deg, #ec4899 0%, #db2777 100%)',
                color: '#fff',
                fontSize: 13,
                fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 4px 14px rgba(236, 72, 153, 0.35)',
                transition: 'all 0.25s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 6px 20px rgba(236, 72, 153, 0.45)';
                e.currentTarget.style.transform = 'translateY(-1px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 4px 14px rgba(236, 72, 153, 0.35)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              Create Event
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
