import { Search, Bell, Plus, ChevronDown } from 'lucide-react';

interface HeaderProps {
  sidebarCollapsed: boolean;
  onAddEvent: () => void;
}

export default function Header({ sidebarCollapsed, onAddEvent }: HeaderProps) {
  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        right: 0,
        left: sidebarCollapsed ? 76 : 264,
        zIndex: 30,
        height: 72,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingLeft: 24,
        paddingRight: 24,
        background: 'rgba(255, 255, 255, 0.85)',
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        borderBottom: '1px solid #e8ecf1',
        transition: 'left 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
      }}
    >
      {/* Search */}
      <div style={{ position: 'relative', width: '100%', maxWidth: 420 }}>
        <Search
          size={16}
          style={{
            position: 'absolute',
            left: 14,
            top: '50%',
            transform: 'translateY(-50%)',
            color: '#94a3b8',
          }}
        />
        <input
          type="text"
          placeholder="Search events, categories, locations..."
          style={{
            height: 42,
            width: '100%',
            borderRadius: 12,
            border: '1.5px solid #e8ecf1',
            background: '#f8fafc',
            paddingLeft: 40,
            paddingRight: 16,
            fontSize: 13,
            color: '#334155',
            transition: 'all 0.2s ease',
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = '#0bb5ae';
            e.currentTarget.style.background = '#fff';
            e.currentTarget.style.boxShadow = '0 0 0 3px rgba(11, 181, 174, 0.1)';
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = '#e8ecf1';
            e.currentTarget.style.background = '#f8fafc';
            e.currentTarget.style.boxShadow = 'none';
          }}
        />
      </div>

      {/* Right Side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {/* Add Event CTA */}
        <button
          onClick={onAddEvent}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '10px 20px',
            borderRadius: 12,
            background: 'linear-gradient(135deg, #ec4899 0%, #db2777 100%)',
            color: '#fff',
            fontSize: 13,
            fontWeight: 700,
            border: 'none',
            cursor: 'pointer',
            boxShadow: '0 4px 14px rgba(236, 72, 153, 0.35)',
            transition: 'all 0.25s ease',
            whiteSpace: 'nowrap',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.boxShadow = '0 6px 20px rgba(236, 72, 153, 0.45)';
            e.currentTarget.style.transform = 'translateY(-1px)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.boxShadow = '0 4px 14px rgba(236, 72, 153, 0.35)';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          <Plus size={16} />
          <span>Add Event</span>
        </button>

        {/* Notification */}
        <button
          style={{
            position: 'relative',
            width: 42,
            height: 42,
            borderRadius: 12,
            border: '1.5px solid #e8ecf1',
            background: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = '#cbd5e1';
            e.currentTarget.style.background = '#f8fafc';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = '#e8ecf1';
            e.currentTarget.style.background = '#fff';
          }}
        >
          <Bell size={18} color="#64748b" />
          <span
            style={{
              position: 'absolute',
              top: -5,
              right: -5,
              width: 20,
              height: 20,
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #ec4899, #db2777)',
              color: '#fff',
              fontSize: 10,
              fontWeight: 800,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 2px 6px rgba(236, 72, 153, 0.4)',
              border: '2px solid #fff',
            }}
          >
            3
          </span>
        </button>

        {/* User */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            padding: '6px 12px 6px 6px',
            borderRadius: 12,
            border: '1.5px solid #e8ecf1',
            background: '#fff',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = '#cbd5e1';
            e.currentTarget.style.background = '#f8fafc';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = '#e8ecf1';
            e.currentTarget.style.background = '#fff';
          }}
        >
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: 10,
              overflow: 'hidden',
              background: 'linear-gradient(135deg, #0bb5ae, #067370)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              fontSize: 12,
              fontWeight: 800,
            }}
          >
            AM
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#1e293b' }}>Admin Mall</span>
            <span style={{ fontSize: 10, color: '#94a3b8', fontWeight: 500 }}>Manager</span>
          </div>
          <ChevronDown size={14} color="#94a3b8" />
        </div>
      </div>
    </header>
  );
}
