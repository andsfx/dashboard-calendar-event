export type EventCategory = 'music' | 'kids' | 'sale' | 'food' | 'fashion' | 'vip';

export interface MallEvent {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  location: string;
  category: EventCategory;
  isVip: boolean;
  description: string;
  guests?: { name: string; avatar: string }[];
}

const today = new Date();
const year = today.getFullYear();
const month = today.getMonth();

function d(dayOffset: number): string {
  const date = new Date(year, month, today.getDate() + dayOffset);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export const EVENTS: MallEvent[] = [
  {
    id: '1',
    title: 'Jazz Night Live',
    date: d(0),
    startTime: '19:00',
    endTime: '22:00',
    location: 'Main Atrium',
    category: 'music',
    isVip: false,
    description: 'Live jazz performance featuring local artists and smooth melodies.',
    guests: [
      { name: 'Andien', avatar: 'https://i.pravatar.cc/40?img=1' },
      { name: 'Tompi', avatar: 'https://i.pravatar.cc/40?img=2' },
    ],
  },
  {
    id: '2',
    title: 'Kids Art Workshop',
    date: d(0),
    startTime: '10:00',
    endTime: '12:00',
    location: 'Level 2 Gallery',
    category: 'kids',
    isVip: false,
    description: 'Creative art workshop for kids aged 5-12 with professional artists.',
    guests: [
      { name: 'Ms. Luna', avatar: 'https://i.pravatar.cc/40?img=5' },
    ],
  },
  {
    id: '3',
    title: 'Grand Summer Sale',
    date: d(0),
    startTime: '10:00',
    endTime: '21:00',
    location: 'All Tenants',
    category: 'sale',
    isVip: false,
    description: 'Up to 70% off across all participating stores — do not miss out!',
  },
  {
    id: '4',
    title: 'VIP Fashion Gala',
    date: d(1),
    startTime: '18:00',
    endTime: '21:00',
    location: 'Grand Ballroom',
    category: 'vip',
    isVip: true,
    description: 'Exclusive fashion show with top designers and celebrity appearances.',
    guests: [
      { name: 'Luna Maya', avatar: 'https://i.pravatar.cc/40?img=10' },
      { name: 'Dian Sastro', avatar: 'https://i.pravatar.cc/40?img=9' },
      { name: 'Raisa', avatar: 'https://i.pravatar.cc/40?img=16' },
    ],
  },
  {
    id: '5',
    title: 'Food Festival',
    date: d(2),
    startTime: '11:00',
    endTime: '20:00',
    location: 'Outdoor Plaza',
    category: 'food',
    isVip: false,
    description: 'Taste cuisines from 30+ food vendors from around the city.',
  },
  {
    id: '6',
    title: 'K-Pop Dance Battle',
    date: d(3),
    startTime: '14:00',
    endTime: '17:00',
    location: 'Main Atrium',
    category: 'music',
    isVip: false,
    description: 'K-Pop dance competition open for all ages. Prizes for winners!',
    guests: [
      { name: 'DJ Aldi', avatar: 'https://i.pravatar.cc/40?img=12' },
    ],
  },
  {
    id: '7',
    title: 'Mega Midnight Sale',
    date: d(5),
    startTime: '20:00',
    endTime: '00:00',
    location: 'All Floors',
    category: 'sale',
    isVip: true,
    description: 'Once-a-month midnight sale with exclusive VIP-only deals.',
  },
  {
    id: '8',
    title: 'Puppet Show',
    date: d(4),
    startTime: '10:00',
    endTime: '11:30',
    location: 'Kids Zone L3',
    category: 'kids',
    isVip: false,
    description: 'Traditional puppet show entertainment for families.',
  },
  {
    id: '9',
    title: 'Acoustic Afternoon',
    date: d(6),
    startTime: '15:00',
    endTime: '17:00',
    location: 'Rooftop Garden',
    category: 'music',
    isVip: false,
    description: 'Relaxing acoustic session with talented indie artists.',
    guests: [
      { name: 'Nadin', avatar: 'https://i.pravatar.cc/40?img=20' },
    ],
  },
  {
    id: '10',
    title: 'Beauty Masterclass',
    date: d(-2),
    startTime: '13:00',
    endTime: '15:00',
    location: 'Level 1 Lounge',
    category: 'fashion',
    isVip: true,
    description: 'Masterclass with celebrity makeup artists and brand ambassadors.',
    guests: [
      { name: 'Tasya F.', avatar: 'https://i.pravatar.cc/40?img=25' },
      { name: 'Abel C.', avatar: 'https://i.pravatar.cc/40?img=30' },
    ],
  },
  {
    id: '11',
    title: 'Weekend Bazaar',
    date: d(-1),
    startTime: '09:00',
    endTime: '18:00',
    location: 'Ground Floor',
    category: 'sale',
    isVip: false,
    description: 'Local artisan market and thrift finds every weekend.',
  },
  {
    id: '12',
    title: 'Storytime with Authors',
    date: d(7),
    startTime: '10:00',
    endTime: '11:00',
    location: 'Bookstore Corner',
    category: 'kids',
    isVip: false,
    description: 'Meet & greet with popular children\'s book authors.',
  },
  {
    id: '13',
    title: 'EDM Night Blast',
    date: d(8),
    startTime: '21:00',
    endTime: '01:00',
    location: 'Rooftop Stage',
    category: 'music',
    isVip: true,
    description: 'High-energy EDM night with international DJs.',
    guests: [
      { name: 'DJ Snake', avatar: 'https://i.pravatar.cc/40?img=33' },
    ],
  },
  {
    id: '14',
    title: 'Flash Sale Friday',
    date: d(10),
    startTime: '12:00',
    endTime: '14:00',
    location: 'Fashion Wing',
    category: 'sale',
    isVip: false,
    description: 'Two-hour flash sale on premium fashion brands.',
  },
  {
    id: '15',
    title: 'Charity Gala Dinner',
    date: d(12),
    startTime: '18:30',
    endTime: '22:00',
    location: 'Grand Ballroom',
    category: 'vip',
    isVip: true,
    description: 'Annual charity event with celebrity performances and auctions.',
    guests: [
      { name: 'Afgan', avatar: 'https://i.pravatar.cc/40?img=35' },
      { name: 'Rossa', avatar: 'https://i.pravatar.cc/40?img=36' },
    ],
  },
];

export interface CategoryMeta {
  label: string;
  color: string;
  bgColor: string;
  icon: string;
}

export const CATEGORY_CONFIG: Record<EventCategory, CategoryMeta> = {
  music:   { label: 'Music',   color: '#0891b2', bgColor: '#ecfeff', icon: '🎵' },
  kids:    { label: 'Kids',    color: '#f59e0b', bgColor: '#fffbeb', icon: '🧸' },
  sale:    { label: 'Sale',    color: '#10b981', bgColor: '#ecfdf5', icon: '🏷️' },
  food:    { label: 'Food',    color: '#f97316', bgColor: '#fff7ed', icon: '🍔' },
  fashion: { label: 'Fashion', color: '#8b5cf6', bgColor: '#f5f3ff', icon: '👗' },
  vip:     { label: 'VIP',     color: '#ec4899', bgColor: '#fdf2f8', icon: '⭐' },
};
