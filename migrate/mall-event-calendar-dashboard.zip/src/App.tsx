import { useState, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import KpiCards from './components/KpiCards';
import Calendar from './components/Calendar';
import AgendaPanel from './components/AgendaPanel';
import AddEventModal from './components/AddEventModal';
import { EVENTS, CATEGORY_CONFIG } from './data/events';
import type { MallEvent, EventCategory } from './data/events';

export default function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeNav, setActiveNav] = useState('dashboard');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());
  const [showAddModal, setShowAddModal] = useState(false);
  const [events, setEvents] = useState<MallEvent[]>(EVENTS);
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const kpiData = useMemo(() => {
    const now = new Date();
    const yr = now.getFullYear();
    const mo = now.getMonth();

    const thisMonth = events.filter((e) => {
      const dt = new Date(e.date);
      return dt.getFullYear() === yr && dt.getMonth() === mo;
    });

    const startWeek = new Date(now);
    startWeek.setDate(now.getDate() - now.getDay());
    startWeek.setHours(0, 0, 0, 0);
    const endWeek = new Date(startWeek);
    endWeek.setDate(startWeek.getDate() + 7);

    const upcoming = events.filter((e) => {
      const dt = new Date(e.date);
      return dt >= now && dt < endWeek;
    });

    const promos = events.filter(
      (e) => e.category === 'sale' && new Date(e.date) >= new Date(now.toDateString())
    );

    return { total: thisMonth.length, upcoming: upcoming.length, promos: promos.length };
  }, [events]);

  const handlePrevMonth = () =>
    setCurrentDate((p) => new Date(p.getFullYear(), p.getMonth() - 1, 1));
  const handleNextMonth = () =>
    setCurrentDate((p) => new Date(p.getFullYear(), p.getMonth() + 1, 1));
  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setCurrentDate(new Date(date.getFullYear(), date.getMonth(), 1));
  };
  const handleAddEvent = (event: MallEvent) => {
    setEvents((prev) => [...prev, event]);
    setShowAddModal(false);
  };

  const filteredEvents = useMemo(() => {
    let filtered = [...events];
    if (activeFilter !== 'all') {
      filtered = filtered.filter((e) =>
        activeFilter === 'vip' ? e.isVip : e.category === activeFilter
      );
    }
    return filtered.sort(
      (a, b) => a.date.localeCompare(b.date) || a.startTime.localeCompare(b.startTime)
    );
  }, [events, activeFilter]);

  const filterBtnStyle = (isActive: boolean): React.CSSProperties => ({
    padding: '6px 14px',
    borderRadius: 10,
    border: isActive ? '1.5px solid #0bb5ae' : '1.5px solid #e8ecf1',
    background: isActive ? 'rgba(11, 181, 174, 0.08)' : '#fff',
    color: isActive ? '#067370' : '#64748b',
    fontSize: 11,
    fontWeight: 700,
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    textTransform: 'capitalize' as const,
  });

  return (
    <div style={{ minHeight: '100vh', background: '#F8FAFC' }}>
      <Sidebar
        activeNav={activeNav}
        onNavChange={setActiveNav}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      <Header
        sidebarCollapsed={sidebarCollapsed}
        onAddEvent={() => setShowAddModal(true)}
      />

      <main
        style={{
          paddingTop: 72,
          marginLeft: sidebarCollapsed ? 76 : 264,
          transition: 'margin-left 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        <div style={{ padding: 24 }}>
          {/* Page Title */}
          <div style={{ marginBottom: 24 }}>
            <h1 style={{ fontSize: 22, fontWeight: 800, color: '#1e293b' }}>
              Event Dashboard
            </h1>
            <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4, fontWeight: 500 }}>
              Metropolitan Mall Bekasi — Manage and monitor all mall events
            </p>
          </div>

          {/* KPI Cards */}
          <div style={{ marginBottom: 24 }}>
            <KpiCards
              totalEvents={kpiData.total}
              upcomingThisWeek={kpiData.upcoming}
              activePromos={kpiData.promos}
            />
          </div>

          {/* Calendar + Agenda */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24, marginBottom: 24 }}>
            <Calendar
              currentDate={currentDate}
              onPrevMonth={handlePrevMonth}
              onNextMonth={handleNextMonth}
              events={events}
              onDateClick={handleDateClick}
              selectedDate={selectedDate}
            />
            <AgendaPanel events={events} selectedDate={selectedDate} />
          </div>

          {/* Events Table */}
          <div
            className="card animate-fade-in-up"
            style={{ padding: 24, animationDelay: '350ms' }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-start',
                marginBottom: 20,
                flexWrap: 'wrap',
                gap: 12,
              }}
            >
              <div>
                <h3 style={{ fontSize: 17, fontWeight: 800, color: '#1e293b' }}>
                  All Upcoming Events
                </h3>
                <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 4, fontWeight: 500 }}>
                  Events across all categories
                </p>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {(['all', 'music', 'kids', 'sale', 'vip'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setActiveFilter(f)}
                    style={filterBtnStyle(activeFilter === f)}
                    onMouseEnter={(e) => {
                      if (activeFilter !== f) {
                        e.currentTarget.style.borderColor = '#0bb5ae';
                        e.currentTarget.style.background = 'rgba(11, 181, 174, 0.04)';
                        e.currentTarget.style.color = '#067370';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (activeFilter !== f) {
                        e.currentTarget.style.borderColor = '#e8ecf1';
                        e.currentTarget.style.background = '#fff';
                        e.currentTarget.style.color = '#64748b';
                      }
                    }}
                  >
                    {f === 'all' ? 'All' : f}
                  </button>
                ))}
              </div>
            </div>

            {/* Table */}
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    {['Event', 'Date', 'Time', 'Location', 'Category', 'Status'].map((h) => (
                      <th
                        key={h}
                        style={{
                          textAlign: 'left',
                          padding: '0 16px 14px 0',
                          fontSize: 11,
                          fontWeight: 700,
                          textTransform: 'uppercase',
                          letterSpacing: '0.06em',
                          color: '#94a3b8',
                          borderBottom: '1.5px solid #e8ecf1',
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredEvents.slice(0, 8).map((event, idx) => {
                    const eventDate = new Date(event.date + 'T00:00:00');
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    const isPast = eventDate < today;
                    const isToday = eventDate.getTime() === today.getTime();
                    const cat = CATEGORY_CONFIG[event.category as EventCategory];

                    return (
                      <tr
                        key={event.id}
                        className="animate-fade-in"
                        style={{
                          borderBottom: '1px solid #f1f5f9',
                          transition: 'background 0.15s ease',
                          animationDelay: `${400 + idx * 40}ms`,
                          cursor: 'default',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = '#f8fafc';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = 'transparent';
                        }}
                      >
                        {/* Event */}
                        <td style={{ padding: '14px 16px 14px 0' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                            <div
                              style={{
                                width: 8,
                                height: 8,
                                borderRadius: '50%',
                                flexShrink: 0,
                                background: event.isVip
                                  ? 'linear-gradient(135deg, #ec4899, #db2777)'
                                  : 'linear-gradient(135deg, #0bb5ae, #089490)',
                                boxShadow: event.isVip
                                  ? '0 0 6px rgba(236, 72, 153, 0.3)'
                                  : '0 0 6px rgba(11, 181, 174, 0.3)',
                              }}
                            />
                            <div>
                              <p style={{ fontSize: 13, fontWeight: 700, color: '#1e293b' }}>
                                {event.title}
                              </p>
                              <p
                                style={{
                                  fontSize: 11,
                                  color: '#94a3b8',
                                  marginTop: 2,
                                  maxWidth: 220,
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  whiteSpace: 'nowrap',
                                  fontWeight: 500,
                                }}
                              >
                                {event.description}
                              </p>
                            </div>
                          </div>
                        </td>

                        {/* Date */}
                        <td style={{ padding: '14px 16px 14px 0' }}>
                          <span style={{ fontSize: 13, color: '#475569', fontWeight: 500 }}>
                            {eventDate.toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                            })}
                          </span>
                        </td>

                        {/* Time */}
                        <td style={{ padding: '14px 16px 14px 0' }}>
                          <span style={{ fontSize: 13, color: '#475569', fontWeight: 500 }}>
                            {event.startTime} - {event.endTime}
                          </span>
                        </td>

                        {/* Location */}
                        <td style={{ padding: '14px 16px 14px 0' }}>
                          <span style={{ fontSize: 13, color: '#475569', fontWeight: 500 }}>
                            {event.location}
                          </span>
                        </td>

                        {/* Category */}
                        <td style={{ padding: '14px 16px 14px 0' }}>
                          <span
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: 4,
                              padding: '3px 10px',
                              borderRadius: 8,
                              fontSize: 11,
                              fontWeight: 700,
                              background: event.isVip ? 'rgba(236, 72, 153, 0.1)' : cat.bgColor,
                              color: event.isVip ? '#be185d' : cat.color,
                            }}
                          >
                            {cat.icon} {cat.label}
                          </span>
                        </td>

                        {/* Status */}
                        <td style={{ padding: '14px 0 14px 0' }}>
                          <span
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: 4,
                              padding: '3px 10px',
                              borderRadius: 8,
                              fontSize: 11,
                              fontWeight: 700,
                              background: isPast
                                ? '#f1f5f9'
                                : isToday
                                ? 'rgba(16, 185, 129, 0.1)'
                                : 'rgba(59, 130, 246, 0.1)',
                              color: isPast ? '#94a3b8' : isToday ? '#059669' : '#2563eb',
                            }}
                          >
                            <span
                              style={{
                                width: 5,
                                height: 5,
                                borderRadius: '50%',
                                background: isPast ? '#cbd5e1' : isToday ? '#10b981' : '#3b82f6',
                              }}
                            />
                            {isPast ? 'Completed' : isToday ? 'Live' : 'Upcoming'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {filteredEvents.length === 0 && (
                <div
                  style={{
                    textAlign: 'center',
                    padding: '40px 20px',
                    color: '#94a3b8',
                    fontSize: 14,
                    fontWeight: 500,
                  }}
                >
                  No events found for this filter.
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <AddEventModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={handleAddEvent}
      />
    </div>
  );
}
